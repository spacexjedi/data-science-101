# Pandas Python: Data Wrangling para Ciência de Dados

Material de apoio do livro "Pandas Python: Data Wrangling para Ciência de Dados" de Eduardo Corrêa.

Mais informações em: https://www.casadocodigo.com.br/products/livro-pandas-python


